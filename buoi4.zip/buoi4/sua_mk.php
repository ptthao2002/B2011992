
<!DOCTYPE HTML>

<html>  
<body>
<h1>Thay đổi mật khẩu</h1>

<form action="sua_mk_save.php" method="post">
Email: <input type="text" name="email"><br>
Password: <input type="password" name="pass"><br>
New Password: <input type="password" name="pass1"><br>
Retype Password: <input type="password" name="pass2"><br>
<input type="submit">
</form>

</body>
</html>



