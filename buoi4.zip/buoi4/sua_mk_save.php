
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlbanhang";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

    $old_past = md5($_POST['pass']);
    $pass1 = md5($_POST['pass1']);
    $pass2 = md5($_POST['pass2']);


$sql = "select password from customers where email = '".$_POST['email']."' and password = '".$_POST["pass"]."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();  
/*  $cookie_name = "user";
  $cookie_value = $row['email'] ;
  setcookie($cookie_name, $cookie_value, time() + (86400 / 24), "/");
  setcookie("fullname", $row['fullname'], time() + (86400 / 24), "/");
  setcookie("id", $row['id'], time() + (86400 / 24), "/");
*/  

if ($old_past["pass"] != $row['password']){
    echo "Doi mat khau khong thanh cong";
}
else if($row["password"] === $pass1){
    echo "Doi mat khau khong thanh cong";
    }
    else if($pass1 != $pass2){
        echo "Doi mat khau khong thanh cong";
    }
    else{
        $username = $_COOKIE["user"];
        $sql = "UPDATE customers set password = '" .md5($_POST["pass1"])."'";
        $sql = $sql. "WHERE email='$user'";
            if($conn->query($sql) == true){
                echo "Doi mat khau thanh cong";
            }
            else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
    }
}
header('Refresh: 3;url=sua_mk.php');
$conn->close();
?>